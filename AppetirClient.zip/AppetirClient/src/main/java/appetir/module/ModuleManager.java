package appetir.module;

import java.util.ArrayList;

public class ModuleManager {

    public ArrayList<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new Module("HUD"));
        modules.add(new Module("ClickGUI"));
        modules.add(new Module("ESP"));
    }

    public ArrayList<Module> getModules() {
        return modules;
    }
}

package appetir.module;

public class Module {

    public String name;
    public boolean enabled;
    public float anim;

    public Module(String name) {
        this.name = name;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
}

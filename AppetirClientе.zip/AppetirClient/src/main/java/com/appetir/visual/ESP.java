package appetir.visual;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;
import appetir.render.RenderUtil;

public class ESP {

    public void render(MatrixStack ms) {
        Minecraft mc = Minecraft.getInstance();

        for (PlayerEntity p : mc.world.getPlayers()) {

            if (p == mc.player) continue;

            double x = p.getPosX() - mc.getRenderManager().info.getProjectedView().x;
            double y = p.getPosY() - mc.getRenderManager().info.getProjectedView().y;
            double z = p.getPosZ() - mc.getRenderManager().info.getProjectedView().z;

            float size = 0.5f;

            // УПРОЩЕННЫЙ 2D BOX
            RenderUtil.drawRect(
                    (float)x - size,
                    (float)y,
                    size * 2,
                    1.8f,
                    0x55FF0000
            );
        }
    }
}
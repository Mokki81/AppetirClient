package appetir;

import net.minecraftforge.fml.common.Mod;
import appetir.module.ModuleManager;

@Mod("appetir")
public class Main {

    public static Main instance;
    public ModuleManager moduleManager;

    public Main() {
        instance = this;
        moduleManager = new ModuleManager();
    }
}

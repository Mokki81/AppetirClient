package appetir.render;

public class ColorUtil {

    public static int rainbow(int offset) {
        float hue = (System.currentTimeMillis() + offset) % 2000L;
        return java.awt.Color.HSBtoRGB(hue / 2000f, 1, 1);
    }
}
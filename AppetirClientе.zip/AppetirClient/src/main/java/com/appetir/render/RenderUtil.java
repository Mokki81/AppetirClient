package appetir.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.AbstractGui;

public class RenderUtil extends AbstractGui {

    // Обычный прямоугольник
    public static void drawRect(float x, float y, float w, float h, int color) {
        fill((int)x, (int)y, (int)(x + w), (int)(y + h), color);
    }

    // Прозрачный прямоугольник
    public static void drawAlphaRect(float x, float y, float w, float h, int color, float alpha) {
        int a = (int)(alpha * 255) << 24;
        int rgb = color & 0x00FFFFFF;
        fill((int)x, (int)y, (int)(x + w), (int)(y + h), a | rgb);
    }

    // Обводка (outline)
    public static void drawOutline(float x, float y, float w, float h, int color) {
        drawRect(x, y, w, 1, color);
        drawRect(x, y + h - 1, w, 1, color);
        drawRect(x, y, 1, h, color);
        drawRect(x + w - 1, y, 1, h, color);
    }

    // Градиент (вертикальный)
    public static void drawGradient(float x, float y, float w, float h, int c1, int c2) {
        fillGradient((int)x, (int)y, (int)(x + w), (int)(y + h), c1, c2);
    }

    // Градиент горизонтальный
    public static void drawGradientSide(float x, float y, float w, float h, int left, int right) {
        for (int i = 0; i < w; i++) {
            float t = i / w;
            int color = blend(left, right, t);
            drawRect(x + i, y, 1, h, color);
        }
    }

    // Смешивание цветов
    public static int blend(int c1, int c2, float t) {
        int r = (int)(((c1 >> 16 & 255) * (1 - t)) + ((c2 >> 16 & 255) * t));
        int g = (int)(((c1 >> 8 & 255) * (1 - t)) + ((c2 >> 8 & 255) * t));
        int b = (int)(((c1 & 255) * (1 - t)) + ((c2 & 255) * t));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // Тень (простая fake shadow)
    public static void drawShadow(float x, float y, float w, float h) {
        drawAlphaRect(x + 2, y + 2, w, h, 0x000000, 0.3f);
    }

    // Подготовка рендера (для ESP и GUI)
    public static void startRender() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public static void stopRender() {
        RenderSystem.disableBlend();
    }
}

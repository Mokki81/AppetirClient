package appetir.render;

public class AnimUtil {

    public static float lerp(float a, float b, float speed) {
        return a + (b - a) * speed;
    }
}
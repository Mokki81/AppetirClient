package appetir;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.mojang.blaze3d.matrix.MatrixStack;

import appetir.gui.hud.KeystrokesHUD;
import appetir.visual.ESP;
import appetir.gui.hud.ArrayListHUD;
import appetir.gui.hud.Watermark;

@Mod.EventBusSubscriber(modid = "appetir", value = Dist.CLIENT)
public class ClientEvents {
    static appetir.gui.hud.TargetHUD target = new appetir.gui.hud.TargetHUD();
    static KeystrokesHUD keys = new KeystrokesHUD();
    static ESP esp = new ESP();
    static ArrayListHUD array = new ArrayListHUD();
    static Watermark watermark = new Watermark();

    @SubscribeEvent
    public static void onRender(RenderGameOverlayEvent.Post e) {

        MatrixStack ms = e.getMatrixStack();

        keys.render();
        array.render(ms);
        watermark.render(ms);
    }

    @SubscribeEvent
    public static void onWorldRender(net.minecraftforge.client.event.RenderWorldLastEvent e) {
        esp.render(e.getMatrixStack());
    }
}
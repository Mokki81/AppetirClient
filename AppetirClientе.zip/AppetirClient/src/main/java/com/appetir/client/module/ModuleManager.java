package com.appetir.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private static final List<Module> modules = new ArrayList<>();

    public static void init() {
        // РЕГИСТРАЦИЯ МОДУЛЕЙ
        // modules.add(new KillAura());
        // modules.add(new ESP());
        // modules.add(new ClickGUI());
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static List<Module> getModulesByCategory(Category category) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                list.add(m);
            }
        }
        return list;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public static void onUpdate() {
        for (Module m : modules) {
            if (m.isToggled()) {
                m.onUpdate();
            }
        }
    }

    public static void onRender2D() {
        for (Module m : modules) {
            if (m.isToggled()) {
                m.onRender2D();
            }
        }
    }

    public static void onRender3D() {
        for (Module m : modules) {
            if (m.isToggled()) {
                m.onRender3D();
            }
        }
    }
}

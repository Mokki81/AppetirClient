package com.appetir.client.module;

import net.minecraft.client.Minecraft;

public class Module {

    protected String name;
    protected Category category;
    protected int key;
    protected boolean toggled;

    protected Minecraft mc = Minecraft.getInstance();

    public Module(String name, Category category, int key) {
        this.name = name;
        this.category = category;
        this.key = key;
        this.toggled = false;
    }

    public void toggle() {
        toggled = !toggled;
        if (toggled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onUpdate() {}
    public void onRender2D() {}
    public void onRender3D() {}

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public int getKey() {
        return key;
    }

    public boolean isToggled() {
        return toggled;
    }

    public void setKey(int key) {
        this.key = key;
    }
}

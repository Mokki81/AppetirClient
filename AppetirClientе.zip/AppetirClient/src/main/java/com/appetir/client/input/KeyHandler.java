package com.appetir.client.input;

import com.appetir.client.module.Module;
import com.appetir.client.module.ModuleManager;
import org.lwjgl.glfw.GLFW;

public class KeyHandler {

    public static void onKey(int key) {
        if (key == GLFW.GLFW_KEY_UNKNOWN) return;

        for (Module module : ModuleManager.getModules()) {
            if (module.getKey() == key) {
                module.toggle();
            }
        }
    }
}
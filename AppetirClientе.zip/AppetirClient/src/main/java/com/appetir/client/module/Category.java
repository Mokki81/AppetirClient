package com.appetir.client.module;

public enum Category {
    COMBAT,
    MOVEMENT,
    RENDER,
    HUD,
    MISC,
    PLAYER
}
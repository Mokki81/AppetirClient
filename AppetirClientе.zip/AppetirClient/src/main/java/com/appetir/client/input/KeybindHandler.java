package appetir;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.Minecraft;
import appetir.gui.clickgui.ClickGUI;

@Mod.EventBusSubscriber(modid = "appetir", value = Dist.CLIENT)
public class KeybindHandler {

    @SubscribeEvent
    public static void onKey(InputEvent.KeyInputEvent e) {

        if (e.getKey() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            Minecraft.getInstance().displayGuiScreen(new ClickGUI());
        }
    }
}
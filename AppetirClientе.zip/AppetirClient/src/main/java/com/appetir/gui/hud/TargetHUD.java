package appetir.gui.hud;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;

public class TargetHUD {

    public void render(MatrixStack ms) {
        Minecraft mc = Minecraft.getInstance();

        PlayerEntity target = null;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p != mc.player) {
                target = p;
                break;
            }
        }

        if (target == null) return;

        int x = 200;
        int y = 200;

        mc.fontRenderer.drawString(ms,
                "Target: " + target.getName().getString(),
                x, y, 0xFFFFFF);

        mc.fontRenderer.drawString(ms,
                "HP: " + (int)target.getHealth(),
                x, y + 12, 0xFF5555);
    }
}
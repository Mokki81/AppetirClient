package appetir.gui.hud;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import appetir.Main;
import appetir.render.AnimUtil;

public class ArrayListHUD {

    public void render(MatrixStack ms) {
        Minecraft mc = Minecraft.getInstance();

        int y = 10;

        for (var m : Main.instance.moduleManager.getModules()) {

            m.anim = AnimUtil.lerp(m.anim, m.enabled ? 1 : 0, 0.1f);

            if (m.anim < 0.01f) continue;

            int offset = (int)(m.anim * 60);

            mc.fontRenderer.drawString(ms,
                    m.name,
                    mc.getMainWindow().getScaledWidth() - offset,
                    y,
                    0xFFFFFF);

            y += 12;
        }
    }
}
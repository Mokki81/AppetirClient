package appetir.gui.hud;

import net.minecraft.client.Minecraft;
import appetir.render.ColorUtil;

public class KeystrokesHUD {

    public void render() {
        Minecraft mc = Minecraft.getInstance();

        mc.fontRenderer.drawString("W", 50, 50, ColorUtil.rainbow(0));
        mc.fontRenderer.drawString("A", 30, 70, ColorUtil.rainbow(200));
        mc.fontRenderer.drawString("S", 50, 70, ColorUtil.rainbow(400));
        mc.fontRenderer.drawString("D", 70, 70, ColorUtil.rainbow(600));
    }
}

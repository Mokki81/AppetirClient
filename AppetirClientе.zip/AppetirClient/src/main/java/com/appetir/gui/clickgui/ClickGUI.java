package appetir.gui.clickgui;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;
import appetir.Main;
import appetir.render.RenderUtil;
import appetir.render.AnimUtil;

public class ClickGUI extends Screen {

    float anim = 0;

    public ClickGUI() {
        super(new StringTextComponent("Appetir"));
    }

    @Override
    public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(ms);

        anim = AnimUtil.lerp(anim, 1, 0.08f);

        float w = 250 * anim;
        float h = 300 * anim;

        float x = this.width / 2f - w / 2f;
        float y = this.height / 2f - h / 2f;

        RenderUtil.drawRect(x, y, w, h, 0x90000000);

        int offsetY = (int) (y + 20);

        for (var m : Main.instance.moduleManager.getModules()) {
            drawString(ms, this.font, m.name + (m.enabled ? " [ON]" : " [OFF]"),
                    (int)x + 10, offsetY,
                    m.enabled ? 0x00FF00 : 0xFFFFFF);

            offsetY += 15;
        }

        super.render(ms, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {

        float w = 250;
        float h = 300;

        float x = this.width / 2f - w / 2f;
        float y = this.height / 2f - h / 2f;

        int offsetY = (int) (y + 20);

        for (var m : Main.instance.moduleManager.getModules()) {

            if (mouseX > x && mouseX < x + w &&
                mouseY > offsetY && mouseY < offsetY + 15) {

                m.toggle();
            }

            offsetY += 15;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }
}

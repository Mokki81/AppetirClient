package appetir.gui.hud;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;

public class Watermark {

    public void render(MatrixStack ms) {
        Minecraft mc = Minecraft.getInstance();

        mc.fontRenderer.drawString(ms,
                "Appetir Client",
                5,
                5,
                0xFFFFFF);
    }
}
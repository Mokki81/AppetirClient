package com.appetir.input;

import com.appetir.AppetirClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class KeyInputHandler {

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            for (var m : AppetirClient.moduleManager.getModules()) {
                if (m.key != -1 &&
                        org.lwjgl.glfw.GLFW.glfwGetKey(
                                client.getWindow().getHandle(),
                                m.key
                        ) == 1) {
                    m.toggle();
                }
            }
        });
    }
}
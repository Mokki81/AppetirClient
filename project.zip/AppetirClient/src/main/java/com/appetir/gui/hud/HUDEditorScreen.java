package com.appetir.gui.hud;

import com.appetir.AppetirClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class HUDEditorScreen extends Screen {

    public HUDEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);

        AppetirClient.hudManager.render(matrices);
        AppetirClient.hudManager.update(mouseX, mouseY);

        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (DraggableComponent c : AppetirClient.hudManager.getComponents()) {
            c.mouseClicked((int) mouseX, (int) mouseY);
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (DraggableComponent c : AppetirClient.hudManager.getComponents()) {
            c.mouseReleased();
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }
}
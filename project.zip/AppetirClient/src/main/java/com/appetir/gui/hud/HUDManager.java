package com.appetir.gui.hud;

import net.minecraft.client.util.math.MatrixStack;

public class HUDManager {

    public void render(MatrixStack matrices) {
        // базовый HUD
    }
}
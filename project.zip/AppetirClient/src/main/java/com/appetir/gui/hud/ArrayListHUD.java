package com.appetir.gui.hud;

import com.appetir.AppetirClient;
import net.minecraft.client.util.math.MatrixStack;

public class ArrayListHUD extends DraggableComponent {

    @Override
    public String getName() {
        return "ArrayList";
    }

    @Override
    public void render(MatrixStack matrices) {
        int offset = 0;

        for (var m : AppetirClient.moduleManager.getModules()) {
            if (m.isEnabled()) {
                net.minecraft.client.MinecraftClient.getInstance().textRenderer.drawWithShadow(
                        matrices,
                        m.getName(),
                        x,
                        y + offset,
                        0xFFFFFFFF
                );
                offset += 10;
            }
        }
    }
}
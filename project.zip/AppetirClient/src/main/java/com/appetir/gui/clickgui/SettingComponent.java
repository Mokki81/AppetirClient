package com.appetir.gui.clickgui;

public class SettingComponent {
}
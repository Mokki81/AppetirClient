package com.appetir.gui.clickgui;

import com.appetir.module.Module;
import net.minecraft.client.util.math.MatrixStack;

public class ModuleButton {

    private final Module module;
    private final Panel parent;

    private int x, y;

    public ModuleButton(Module module, Panel parent) {
        this.module = module;
        this.parent = parent;
    }

    public void render(MatrixStack matrices, int mouseX, int mouseY, int x, int y) {
        this.x = x;
        this.y = y;

        int color = module.isEnabled() ? 0xFF00FF00 : 0xFFFFFFFF;

        net.minecraft.client.MinecraftClient.getInstance().textRenderer.drawWithShadow(
                matrices,
                module.getName(),
                x,
                y,
                color
        );
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (mouseX > x && mouseX < x + 80 && mouseY > y && mouseY < y + 12) {
            if (button == 0) {
                module.toggle();
            }
        }
    }
}
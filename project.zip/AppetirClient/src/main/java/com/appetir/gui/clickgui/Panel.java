package com.appetir.gui.clickgui;

import com.appetir.AppetirClient;
import com.appetir.module.Module;
import com.appetir.module.Category;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;

public class Panel {

    private final Category category;
    private int x, y;
    private boolean dragging;

    private final List<ModuleButton> buttons = new ArrayList<>();

    public Panel(Category category, int x, int y) {
        this.category = category;
        this.x = x;
        this.y = y;

        for (Module m : AppetirClient.moduleManager.getModules()) {
            if (m.getCategory() == category) {
                buttons.add(new ModuleButton(m, this));
            }
        }
    }

    public void render(MatrixStack matrices, int mouseX, int mouseY) {
        net.minecraft.client.MinecraftClient.getInstance().textRenderer.drawWithShadow(
                matrices,
                category.name(),
                x,
                y,
                0xFFFFFFFF
        );

        int offset = 15;

        for (ModuleButton b : buttons) {
            b.render(matrices, mouseX, mouseY, x, y + offset);
            offset += 15;
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (mouseX > x && mouseX < x + 80 && mouseY > y && mouseY < y + 12) {
            dragging = true;
        }

        for (ModuleButton b : buttons) {
            b.mouseClicked(mouseX, mouseY, button);
        }
    }

    public void mouseReleased() {
        dragging = false;
    }

    public void mouseDragged(int mouseX, int mouseY) {
        if (dragging) {
            x = mouseX;
            y = mouseY;
        }
    }
}
package com.appetir.gui.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class KeystrokesHUD extends DraggableComponent {

    @Override
    public String getName() {
        return "Keystrokes";
    }

    @Override
    public void render(MatrixStack matrices) {
        MinecraftClient mc = MinecraftClient.getInstance();

        mc.textRenderer.drawWithShadow(matrices, "W", x + 10, y, 0xFFFFFFFF);
        mc.textRenderer.drawWithShadow(matrices, "A", x, y + 10, 0xFFFFFFFF);
        mc.textRenderer.drawWithShadow(matrices, "S", x + 10, y + 10, 0xFFFFFFFF);
        mc.textRenderer.drawWithShadow(matrices, "D", x + 20, y + 10, 0xFFFFFFFF);
    }
}
package com.appetir.render;

import java.awt.*;

public class ColorUtil {

    public static int rainbow(int speed) {
        float hue = (System.currentTimeMillis() % speed) / (float) speed;
        return Color.HSBtoRGB(hue, 1, 1);
    }
}
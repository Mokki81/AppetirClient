package com.appetir.render;

public class AnimUtil {

    public static float lerp(float a, float b, float f) {
        return a + f * (b - a);
    }
}
package com.appetir;

import com.appetir.gui.hud.HUDManager;
import com.appetir.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

public class AppetirClient implements ClientModInitializer {

    public static ModuleManager moduleManager;
    public static HUDManager hudManager;

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        moduleManager.registerModules();

        hudManager = new HUDManager();
    }
}
package com.appetir.config;

import com.appetir.gui.hud.DraggableComponent;
import com.appetir.gui.hud.HUDManager;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;

public class HUDConfig {

    private static final File file = new File("appetir_hud.txt");

    public static void save(HUDManager manager) {
        try {
            FileWriter writer = new FileWriter(file);

            for (DraggableComponent c : manager.getComponents()) {
                writer.write(c.getName() + ":" + c.getX() + ":" + c.getY() + "\n");
            }

            writer.close();
        } catch (Exception ignored) {}
    }

    public static void load(HUDManager manager) {
        try {
            if (!file.exists()) return;

            for (String line : Files.readAllLines(file.toPath())) {
                String[] data = line.split(":");

                for (DraggableComponent c : manager.getComponents()) {
                    if (c.getName().equalsIgnoreCase(data[0])) {
                        c.setPosition(
                                Integer.parseInt(data[1]),
                                Integer.parseInt(data[2])
                        );
                    }
                }
            }
        } catch (Exception ignored) {}
    }
}
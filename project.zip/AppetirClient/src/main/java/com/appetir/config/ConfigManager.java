package com.appetir.config;

import com.appetir.AppetirClient;
import com.appetir.module.Module;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;

public class ConfigManager {

    private static final File file = new File("appetir_modules.txt");

    public static void save() {
        try {
            FileWriter writer = new FileWriter(file);

            for (Module m : AppetirClient.moduleManager.getModules()) {
                writer.write(m.getName() + ":" + m.isEnabled() + ":" + m.key + "\n");
            }

            writer.close();
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!file.exists()) return;

            for (String line : Files.readAllLines(file.toPath())) {
                String[] data = line.split(":");

                for (Module m : AppetirClient.moduleManager.getModules()) {
                    if (m.getName().equalsIgnoreCase(data[0])) {
                        if (Boolean.parseBoolean(data[1])) m.toggle();
                        m.key = Integer.parseInt(data[2]);
                    }
                }
            }
        } catch (Exception ignored) {}
    }
}
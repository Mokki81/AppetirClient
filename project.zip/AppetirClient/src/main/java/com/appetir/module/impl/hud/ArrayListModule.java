package com.appetir.module.impl.hud;

import com.appetir.AppetirClient;
import com.appetir.gui.hud.ArrayListHUD;
import com.appetir.module.Module;
import com.appetir.module.Category;

public class ArrayListModule extends Module {

    private final ArrayListHUD hud = new ArrayListHUD();

    public ArrayListModule() {
        super("ArrayList", Category.HUD, -1);
    }

    @Override
    public void onEnable() {
        AppetirClient.hudManager.add(hud);
    }

    @Override
    public void onDisable() {
        AppetirClient.hudManager.remove(hud);
    }
}
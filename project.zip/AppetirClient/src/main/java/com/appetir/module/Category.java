package com.appetir.module;

public enum Category {
    RENDER, HUD
}
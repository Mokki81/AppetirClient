package com.appetir.module.impl.render;

import com.appetir.module.Module;
import com.appetir.module.Category;
import net.minecraft.client.util.math.MatrixStack;

public class GlowESP extends Module {

    public GlowESP() {
        super("GlowESP", Category.RENDER, -1);
    }

    @Override
    public void onRender(MatrixStack matrices) {
        // базовая заглушка glow (рабочая без краша)
    }
}
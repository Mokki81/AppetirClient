package com.appetir.module.impl.render;

import com.appetir.module.Module;
import com.appetir.module.Category;
import net.minecraft.client.util.math.MatrixStack;

public class JumpCircles extends Module {

    public JumpCircles() {
        super("JumpCircles", Category.RENDER, -1);
    }

    @Override
    public void onRender(MatrixStack matrices) {
    }
}
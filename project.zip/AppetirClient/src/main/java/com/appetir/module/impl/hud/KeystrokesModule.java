package com.appetir.module.impl.hud;

import com.appetir.AppetirClient;
import com.appetir.gui.hud.KeystrokesHUD;
import com.appetir.module.Module;
import com.appetir.module.Category;

public class KeystrokesModule extends Module {

    private final KeystrokesHUD hud = new KeystrokesHUD();

    public KeystrokesModule() {
        super("Keystrokes", Category.HUD, -1);
    }

    @Override
    public void onEnable() {
        AppetirClient.hudManager.add(hud);
    }

    @Override
    public void onDisable() {
        AppetirClient.hudManager.remove(hud);
    }
}
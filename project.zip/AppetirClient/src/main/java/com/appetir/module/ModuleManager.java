package com.appetir.module;

import com.appetir.module.impl.render.ESP;
import com.appetir.module.impl.render.GlowESP;

import net.minecraft.client.util.math.MatrixStack;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerModules() {
        modules.add(new ESP());
        modules.add(new GlowESP());
    }

    public List<Module> getModules() {
        return modules;
    }

    public void onRender(MatrixStack matrices) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onRender(matrices);
            }
        }
    }
}
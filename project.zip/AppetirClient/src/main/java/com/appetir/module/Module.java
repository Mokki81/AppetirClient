package com.appetir.module;

import net.minecraft.client.util.math.MatrixStack;

public abstract class Module {

    private final String name;
    private final Category category;
    private boolean enabled;
    public int key = -1;

    public Module(String name, Category category, int key) {
        this.name = name;
        this.category = category;
        this.key = key;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public boolean isEnabled() { return enabled; }
    public String getName() { return name; }

    public void onEnable() {}
    public void onDisable() {}
    public void onRender(MatrixStack matrices) {}
}
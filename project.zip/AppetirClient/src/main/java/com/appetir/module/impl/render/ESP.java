package com.appetir.module.impl.render;

import com.appetir.module.Module;
import com.appetir.module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;

public class ESP extends Module {

    public ESP() {
        super("ESP", Category.RENDER, -1);
    }

    @Override
    public void onRender(MatrixStack matrices) {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.world == null) return;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;

            mc.textRenderer.drawWithShadow(
                    matrices,
                    "ESP",
                    10,
                    10,
                    0xFFFF0000
            );
        }
    }
}